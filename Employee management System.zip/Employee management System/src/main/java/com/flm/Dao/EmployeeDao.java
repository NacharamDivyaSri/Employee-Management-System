package com.flm.Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.flm.model.Employee;


public class EmployeeDao {
	private  static Connection con = null;
	private Connection getConnection() {
		System.out.println("Entered into getConnection() method ...");

		String url = "jdbc:mysql://localhost/fsj";
 		String user = "root";
 		String pwd = "Divi@1502957";
 		if(con==null) {
 		try {
  			Class.forName("com.mysql.cj.jdbc.Driver");
  			
  		} catch (ClassNotFoundException e) {
  			// TODO Auto-generated catch block
  			System.out.println("Error: " + e.getMessage());
  		}
 		 try {
 		    con = DriverManager.getConnection(url, user, pwd);
 			System.out.println("connection object is created");
  		} catch (Exception e) {
  			// TODO Auto-generated catch block
  			System.out.println("Error: " + e.getMessage());
  		}
 		}
		return con;
	}
		public void closeConnection() {
			System.out.println("Entered into closeConnection() method ...");
			try {
				con.close();
				System.out.println("Connection object is destoyed ...");
			} catch (Exception ex) {
				System.out.println("Connection error ... " + ex.getMessage());
			}
	 
	}
		public List<Employee> getAllEmployees() {
			System.out.println("Entered into getAllEmployees()...");
			List<Employee> employees = new ArrayList<Employee>();
			try (Statement stmt = getConnection().createStatement();
					ResultSet rs = stmt.executeQuery("select * from employee");) {
				while (rs.next()) {
					long id = rs.getLong("id");
					String name = rs.getString("name");
					String address = rs.getString("address");
					double salary = rs.getDouble("salary");
					Employee emp = new Employee(id, name, address, salary);
					employees.add(emp);
				}
			} catch (SQLException ex) {
				System.out.println("Error : " + ex.getMessage());
			}
			return employees;
		}
		

     public void saveEmployee(Employee emp) {
		
    	 List<Employee> employees = new ArrayList<Employee>();
    	 
 		try (
 				PreparedStatement st =  getConnection().prepareStatement("insert into employee(name,address,salary) values(?,?,?)");
 				)
 				 {

st.setString(1, emp.getName());
st.setString(2,emp.getAddress());
st.setDouble(3, emp.getSalary());
st.execute();
 		} catch (SQLException ex) {
 		System.out.println("Error : " + ex.getMessage());
 		} 
 		
     }
	public void deleteEmployee(Long id) {
		// TODO Auto-generated method stub
		try (PreparedStatement st =  getConnection().prepareStatement("delete from employee where id=?");)
 				
 				 {

st.setLong(1, id);
st.executeUpdate();
 		} catch (SQLException ex) {
 		System.out.println("Error : " + ex.getMessage());
 		} 
 			
	}
	public Employee getEmployee(Long id) {
		System.out.println("Entered into getEmployee()...");
		Employee emp = null;
		try (PreparedStatement pst = getConnection().prepareStatement("select * from employee where id=?");
				) {
			pst.setLong(1, id);
			ResultSet rs = pst.executeQuery();
			rs.next();
			String name = rs.getString("name");
			String address = rs.getString("address");
			double salary = rs.getDouble("salary");
			emp = new Employee(id, name, address, salary);
			
		} catch (SQLException ex) {
			System.out.println("Error : " + ex.getMessage());
		}
		return emp;
	}
	
	public void updateEmployee(Employee emp) {
		System.out.println("Entered into updateEmployee()...");
		try (PreparedStatement pst = getConnection().prepareStatement("update employee set name=?,address=?,salary=? where id=?");) {
			pst.setString(1, emp.getName());
			pst.setString(2, emp.getAddress());
			pst.setDouble(3, emp.getSalary());
			pst.setLong(4, emp.getId());
			pst.execute();
		} catch (SQLException ex) {
			System.out.println("Error : " + ex.getMessage());
		}
	}

}
