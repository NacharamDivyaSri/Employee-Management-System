package com.flm.sevlet;

import java.io.IOException;
import java.util.List;

import com.flm.Dao.EmployeeDao;
import com.flm.model.Employee;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/saveEmployee")
public class saveEmployeeServlet extends HttpServlet {
	
	private EmployeeDao Dao = null;

	
	@Override
	public void init(ServletConfig config) throws ServletException {
		Dao = new EmployeeDao();
		System.out.println("employee object is created");
	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name=request.getParameter("emp_name");
		String address=request.getParameter("emp_address");
		String salary=request.getParameter("emp_salary");
		Employee emp =new Employee(name,address,Double.valueOf(salary));
		Dao.saveEmployee(emp);
		
		response.sendRedirect("fetchAllEmployee");
	}


	
}
