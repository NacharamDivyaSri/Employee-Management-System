package com.flm.sevlet;

import java.io.IOException;

import com.flm.Dao.EmployeeDao;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/deleteEmployee")

public class DeleteEmployeeServlet extends HttpServlet {
	
private EmployeeDao Dao = null;
	
	@Override
	public void init(ServletConfig config) throws ServletException {
		Dao = new EmployeeDao();
		System.out.println("EmployeeDAO object is created ....");
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id =request.getParameter("emp_id");
		Dao.deleteEmployee(Long.valueOf(id));
		response.sendRedirect("fetchAllEmployee");

		
	}

}
