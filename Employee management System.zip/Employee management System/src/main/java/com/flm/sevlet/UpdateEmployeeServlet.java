package com.flm.sevlet;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import com.flm.Dao.EmployeeDao;
import com.flm.model.Employee;

@WebServlet("/updateEmployee")

public class UpdateEmployeeServlet extends HttpServlet {
	
private EmployeeDao dao = null;
	
	@Override
	public void init(ServletConfig config) throws ServletException {
		dao = new EmployeeDao();
		System.out.println("EmployeeDAO object is created ....");
	}


	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	doPost(request, response);	
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id =request.getParameter("emp_id");
		String name =request.getParameter("emp_name");
		String address =request.getParameter("emp_address");
		String salary =request.getParameter("emp_salary");
		Employee emp = new Employee(Long.valueOf(id), name,address,Double.valueOf(salary));
		dao.updateEmployee(emp);
		response.sendRedirect("fetchAllEmployee");	
	}

}
